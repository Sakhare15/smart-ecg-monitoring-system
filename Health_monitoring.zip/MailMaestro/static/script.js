const socket = io();

let ecgChart = null;
let ecgData = [];
let timeData = [];
let peakData = [];
const maxDataPoints = 1500;
let fs = 360;
let sampleCount = 0;

function initChart() {
    const ctx = document.getElementById('ecgChart').getContext('2d');
    
    ecgChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: timeData,
            datasets: [{
                label: 'ECG Signal',
                data: ecgData,
                borderColor: '#00a86b',
                backgroundColor: 'rgba(0, 168, 107, 0.1)',
                borderWidth: 2,
                pointRadius: 0,
                tension: 0.1,
                fill: true
            }, {
                label: 'R-peaks',
                data: peakData,
                borderColor: '#ff4444',
                backgroundColor: '#ff4444',
                pointRadius: 6,
                pointStyle: 'circle',
                showLine: false
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            animation: false,
            scales: {
                x: {
                    type: 'linear',
                    title: {
                        display: true,
                        text: 'Time (seconds)',
                        font: { size: 14 }
                    },
                    grid: {
                        color: '#e0e0e0'
                    }
                },
                y: {
                    title: {
                        display: true,
                        text: 'Amplitude (mV)',
                        font: { size: 14 }
                    },
                    grid: {
                        color: '#e0e0e0'
                    }
                }
            },
            plugins: {
                legend: {
                    display: true,
                    position: 'top'
                },
                tooltip: {
                    enabled: false
                }
            }
        }
    });
}

function updateChart(samples, t0, peaks, bpm, alerts, clinicalSuggestions = []) {
    const newTimeData = samples.map((_, i) => t0 + i / fs);
    
    timeData.push(...newTimeData);
    ecgData.push(...samples);
    
    peaks.forEach(peakIdx => {
        const peakTime = t0 + peakIdx / fs;
        const peakValue = samples[peakIdx];
        peakData.push({ x: peakTime, y: peakValue });
    });
    
    if (timeData.length > maxDataPoints) {
        const excess = timeData.length - maxDataPoints;
        timeData.splice(0, excess);
        ecgData.splice(0, excess);
        
        peakData = peakData.filter(p => p.x >= timeData[0]);
    }
    
    ecgChart.data.labels = timeData;
    ecgChart.data.datasets[0].data = ecgData;
    ecgChart.data.datasets[1].data = peakData;
    ecgChart.update('none');
    
    if (bpm !== null) {
        document.getElementById('bpmDisplay').textContent = Math.round(bpm);
    }
    
    updateAlerts(alerts);
    updateClinicalSuggestions(clinicalSuggestions);
}

function updateAlerts(alerts) {
    const alertsDisplay = document.getElementById('alertsDisplay');
    
    if (alerts.length === 0) {
        alertsDisplay.innerHTML = '<div class="alert-item none">None</div>';
    } else {
        alertsDisplay.innerHTML = alerts.map(alert => 
            `<div class="alert-item active">${alert}</div>`
        ).join('');
    }
}

function updateClinicalSuggestions(suggestions) {
    const panel = document.getElementById('clinicalSuggestions');
    const content = document.getElementById('suggestionsContent');
    
    if (!suggestions || suggestions.length === 0) {
        panel.classList.add('hidden');
        return;
    }
    
    panel.classList.remove('hidden');
    
    content.innerHTML = suggestions.map(suggestion => `
        <div class="suggestion-card severity-${suggestion.severity?.toLowerCase() || 'medium'}">
            <h4>${suggestion.title}</h4>
            <p class="description">${suggestion.description}</p>
            
            <div class="action-section">
                <h5>⚡ Immediate Actions:</h5>
                <ul>
                    ${(suggestion.immediate_actions || []).map(action => `<li>${action}</li>`).join('')}
                </ul>
            </div>
            
            <div class="recommendation-section">
                <h5>📋 Recommendations:</h5>
                <ul>
                    ${(suggestion.recommendations || []).map(rec => `<li>${rec}</li>`).join('')}
                </ul>
            </div>
        </div>
    `).join('');
}

function updateStatus(message, type = 'info') {
    const statusEl = document.getElementById('status');
    statusEl.textContent = message;
    statusEl.className = `status status-${type}`;
}

document.getElementById('startBtn').addEventListener('click', () => {
    socket.emit('start_stream');
    document.getElementById('startBtn').disabled = true;
    document.getElementById('stopBtn').disabled = false;
    updateStatus('Starting ECG stream...', 'info');
});

document.getElementById('stopBtn').addEventListener('click', () => {
    socket.emit('stop_stream');
    document.getElementById('startBtn').disabled = false;
    document.getElementById('stopBtn').disabled = true;
    updateStatus('Stream stopped', 'warning');
});

socket.on('connect', () => {
    console.log('Connected to server');
    updateStatus('Connected - Ready to start', 'success');
});

socket.on('disconnect', () => {
    console.log('Disconnected from server');
    updateStatus('Disconnected from server', 'error');
});

socket.on('stream_started', (data) => {
    console.log('Stream started:', data);
    fs = data.fs;
    ecgData = [];
    timeData = [];
    peakData = [];
    sampleCount = 0;
    
    if (ecgChart) {
        ecgChart.destroy();
    }
    initChart();
    
    updateStatus('Monitoring active...', 'success');
});

socket.on('ecg_chunk', (payload) => {
    updateChart(payload.samples, payload.t0, payload.peaks, payload.bpm, payload.alerts, payload.clinical_suggestions);
    sampleCount += payload.samples.length;
});

socket.on('stream_complete', (data) => {
    console.log('Stream complete:', data);
    updateStatus('Recording complete', 'info');
    document.getElementById('startBtn').disabled = false;
    document.getElementById('stopBtn').disabled = true;
});

socket.on('stream_stopped', (data) => {
    console.log('Stream stopped:', data);
    updateStatus('Stream stopped', 'warning');
});

socket.on('error', (data) => {
    console.error('Error:', data);
    updateStatus('Error: ' + data.message, 'error');
    document.getElementById('startBtn').disabled = false;
    document.getElementById('stopBtn').disabled = true;
});

document.getElementById('settingsBtn').addEventListener('click', () => {
    document.getElementById('settingsModal').classList.remove('hidden');
    socket.emit('get_notification_config');
});

document.getElementById('closeSettings').addEventListener('click', () => {
    document.getElementById('settingsModal').classList.add('hidden');
});

document.getElementById('saveSettings').addEventListener('click', () => {
    const config = {
        email_enabled: document.getElementById('emailEnabled').checked,
        sms_enabled: document.getElementById('smsEnabled').checked,
        recipient_email: document.getElementById('recipientEmail').value,
        recipient_phone: document.getElementById('recipientPhone').value
    };
    
    socket.emit('set_notification_config', config);
});

socket.on('notification_config', (config) => {
    document.getElementById('emailEnabled').checked = config.email_enabled || false;
    document.getElementById('smsEnabled').checked = config.sms_enabled || false;
    document.getElementById('recipientEmail').value = config.recipient_email || '';
    document.getElementById('recipientPhone').value = config.recipient_phone || '';
    
    updateNotificationStatus(config);
});

socket.on('notification_config_updated', (data) => {
    console.log('Notification config updated:', data);
    document.getElementById('settingsModal').classList.add('hidden');
    updateNotificationStatus(data.config);
    updateStatus('Notification settings saved!', 'success');
});

function updateNotificationStatus(config) {
    const statusEl = document.getElementById('notificationStatus');
    const parts = [];
    
    if (config.email_enabled && config.recipient_email) {
        parts.push('✉️ Email');
    }
    if (config.sms_enabled && config.recipient_phone) {
        parts.push('📱 SMS');
    }
    
    if (parts.length > 0) {
        statusEl.textContent = parts.join(', ') + ' enabled';
        statusEl.style.color = '#00a86b';
    } else {
        statusEl.textContent = 'Not configured';
        statusEl.style.color = '#999';
    }
}

window.addEventListener('load', () => {
    initChart();
    socket.emit('get_notification_config');
});
